from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from . import models, schemas, crud
from .database import engine, SessionLocal
from fastapi.middleware.cors import CORSMiddleware

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/")
def root():
    return {"message": "API funcionando"}

@app.post("/tarefas/", response_model=schemas.Tarefa)
def criar(tarefa: schemas.TarefaCreate, db: Session = Depends(get_db)):
    return crud.criar_tarefa(db, tarefa)

@app.get("/tarefas/", response_model=list[schemas.Tarefa])
def listar(db: Session = Depends(get_db)):
    return crud.listar_tarefas(db)

@app.get("/tarefas/{tarefa_id}", response_model=schemas.Tarefa)
def buscar(tarefa_id: int, db: Session = Depends(get_db)):
    db_tarefa = crud.buscar_tarefa(db, tarefa_id)
    if db_tarefa is None:
        raise HTTPException(status_code=404, detail="Tarefa não encontrada")
    return db_tarefa

@app.put("/tarefas/{tarefa_id}", response_model=schemas.Tarefa)
def atualizar(tarefa_id: int, tarefa: schemas.TarefaCreate, db: Session = Depends(get_db)):
    db_tarefa = crud.atualizar_tarefa(db, tarefa_id, tarefa)
    if db_tarefa is None:
        raise HTTPException(status_code=404, detail="Tarefa não encontrada")
    return db_tarefa

@app.delete("/tarefas/{tarefa_id}")
def deletar(tarefa_id: int, db: Session = Depends(get_db)):
    db_tarefa = crud.deletar_tarefa(db, tarefa_id)
    if db_tarefa is None:
        raise HTTPException(status_code=404, detail="Tarefa não encontrada")
    return {"message": "Tarefa deletada"}
