from sqlalchemy import create_engine

DB_USER = "root"
DB_PASSWORD = "12345678"
DB_HOST = "localhost"
DB_PORT = "3306"
DB_NAME = "sistema_db"

DATABASE_URL = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

try:
    engine = create_engine(DATABASE_URL)
    connection = engine.connect()
    print("✅ Conectado ao banco com sucesso!")
    connection.close()
except Exception as e:
    print("❌ Erro ao conectar no banco:")
    print(e)
