from sqlalchemy.orm import Session
from . import models, schemas

def criar_tarefa(db: Session, tarefa: schemas.TarefaCreate):
    nova_tarefa = models.Tarefa(**tarefa.dict())
    db.add(nova_tarefa)
    db.commit()
    db.refresh(nova_tarefa)
    return nova_tarefa

def listar_tarefas(db: Session):
    return db.query(models.Tarefa).all()

def buscar_tarefa(db: Session, tarefa_id: int):
    return db.query(models.Tarefa).filter(models.Tarefa.id == tarefa_id).first()

def atualizar_tarefa(db: Session, tarefa_id: int, tarefa: schemas.TarefaCreate):
    db_tarefa = buscar_tarefa(db, tarefa_id)
    if db_tarefa:
        for key, value in tarefa.dict().items():
            setattr(db_tarefa, key, value)
        db.commit()
        db.refresh(db_tarefa)
    return db_tarefa

def deletar_tarefa(db: Session, tarefa_id: int):
    db_tarefa = buscar_tarefa(db, tarefa_id)
    if db_tarefa:
        db.delete(db_tarefa)
        db.commit()
    return db_tarefa
